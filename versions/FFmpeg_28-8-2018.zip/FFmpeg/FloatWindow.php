<?php
include '../auth.php';
?>
<html>
<body>
Now Loading...
<script src="FloatWindow.js"></script>
<script>
var uid = "ffmpeg";
var fw = new FloatWindow("index.php?embedded=true","FFmpeg (ArOZ Online Wrapper)","exchange", uid);
fw.launch();
</script>
</body>
</html>