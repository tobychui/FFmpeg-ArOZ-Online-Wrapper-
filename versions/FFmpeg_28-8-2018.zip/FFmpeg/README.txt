This is a wrapper for FFmpeg. Licensed under LGPLv2.1 (same as the one given by FFmpeg)
Also, the FFmpeg main binary (or program if you wanna call it like that) is licensed under GNU and it is under its own folder (ffmpeg-{version_number}-win32-static). Please read the license.txt for more information on the license.

Wrapper written by Toby Chui feat. IMUS Laboratory under ArOZ Online Project Beta
Learn more at http://imuslab.com/. 