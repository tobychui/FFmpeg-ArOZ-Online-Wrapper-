<?php
$result = shell_exec('sudo apt-get install libav-tools -y');
echo '<pre>' . $result . '</pre>';
?>
<br>
<a href="index.php">Back</a>